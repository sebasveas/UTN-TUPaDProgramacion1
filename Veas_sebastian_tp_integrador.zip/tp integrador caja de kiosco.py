#TP integrador – Repetitivas- Condicionales y
#Secuenciales.
#Ejercicio 1— “Caja del Kiosco”
#iniciamps con while true para siempre entrar y una vez adentro pedimos datos y validamos
while True:
    nombre = input("por favor ingrese su nombre ( solo letras): ")
    if nombre == "":
        print("error, no puede dejar espacios vacios")
        continue
    elif not nombre.isalpha():
        print("error, ingrese solo letras")
        continue
    break
# pedimos datos y validamos 
while True:
    cant_productos = input("por favor ingrese la cantidad de productos (solo numeros enteros): ")
    if cant_productos == "":
        print("error, no puede dejar espacios vacios")
        continue
    elif not cant_productos.isdigit():
        print("por favor ingrese un numero entero")
        continue
    cant_productos = int(cant_productos)
    if cant_productos < 1 :
        print("ingrese un numero mayor a 0")
        continue
    break
# variables iniciadas en 0 
total_sin_descuento = 0
total_con_descuento = 0
for i in range(1,cant_productos + 1):# usamos for ya que tenemos un dato concreto 
    while True:
        precio = input("por favor ingrese el precio de cada producto: ")
        if precio == "":
            print("error, no puede dejar espacios vacios")
            continue
        elif not precio.isdigit():
            print("por favor, ingrese un numero entero")
            continue
        precio = int(precio) # int para transformar a entero
        break
    total_sin_descuento += precio
    while True:
        descuento = input("¿tiene descuento? responda con (s) si si tiene descuento y con (n) si no tiene descuento: ").lower()
        if descuento != "s" and descuento != "n":
            print("error, ingrese s/n")
            continue
        if descuento == "s" :
            total_con_descuento += precio * 0.9
        else : 
            total_con_descuento += precio
        break
ahorro = total_sin_descuento - total_con_descuento
promedio = total_con_descuento / cant_productos
#salida de datos por pantalla
print(f"\nCliente: {nombre}")
print(f"Total sin descuentos: ${total_sin_descuento}")
print(f"Total con descuentos: ${total_con_descuento:.2f}") 
print(f"Ahorro: ${ahorro:.2f}")
print(f"Promedio por producto: ${promedio:.2f}")






        






   