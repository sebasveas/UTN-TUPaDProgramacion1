#Ejercicio 3 (Alta) — “Agenda de Turnos con Nombres (sin listas)”
# iniciamos colocando variables lunes (4) y martes (3), vacias
lunes1= ""
lunes2 = ""
lunes3 = ""
lunes4 = ""
martes1= ""
martes2 = ""
martes3 = ""
#pedimos el nombre y despues las validamos con while true
while True:
    operador = input("por favor ingrese el nombre del operador: ")
    if operador == "":
        print("error, no puede dejar espacios vacios")
    elif not operador.isalpha():
        print("error, el nombre solo debe contener letras ")
    else:
        break
print(f"\n Bienvenido/a {operador} al sistema de turnos. ")
# iniciamos con la estructura del menu principal
opcion_menu = ""
while opcion_menu != "5":
    print("\n--- MENÚ DE TURNOS ---")
    print("1. Reservar turno")
    print("2. Cancelar turno")
    print("3. Ver agenda del día")
    print("4. Ver resumen general")
    print("5. Cerrar sistema")
    opcion_menu = input("por favor ingrese una opcion: ") 
    if not opcion_menu.isdigit():
        print(" error, ingrese un numero valido")
        continue
#empezamos con las condiciones de cada opcion y validamos los dias
    if opcion_menu == "1":
        while True:
            dia = input(" escriba la opcion del dia (1: lunes) (2: martes): ")
            if dia == "1" or dia == "2":
                break
            print("error, ingrese 1 o 2")
        while True:
            paciente = input("ingrese el nombre del paciente: ")
            if paciente == "":
                print("error, no puede dejar espacios vacios")
            elif not paciente.isalpha():
                print("error, debe ingresar solo letras")
            else:
                break
        if dia == "1":
            if paciente == lunes1 or paciente == lunes2 or paciente == lunes3 or paciente == lunes4:
                print(f"error, el paciente {paciente} ya tiene un turno reservado para el lunes ")
            elif lunes1 == "":
                lunes1 = paciente
                print(f"Turno reservado para {paciente} el Lunes (Turno 1).")
            elif lunes2 == "":
                lunes2 = paciente
                print(f"Turno reservado para {paciente} el Lunes (Turno 2).")
            elif lunes3 == "":
                lunes3 = paciente
                print(f"Turno reservado para {paciente} el Lunes (Turno 3).")
            elif lunes4 == "":
                lunes4 = paciente
                print(f"Turno reservado para {paciente} el Lunes (Turno 4).")
            else:
                print("Error: Ya no quedan turnos disponibles para el Lunes.")
        elif dia == "2":
            if paciente == martes1 or paciente == martes2 or paciente == martes3:
                print(f"error, el paciente {paciente} ya tiene un turno reservado para el martes ")
            elif martes1 == "":
                martes1 = paciente
                print(f"Turno reservado para {paciente} el Martes (Turno 1).")
            elif martes2 == "":
                martes2 = paciente
                print(f"Turno reservado para {paciente} el Martes (Turno 2).")
            elif martes3 == "":
                martes3 = paciente
                print(f"Turno reservado para {paciente} el Martes (Turno 3).")
            else:
                print("Error: Ya no quedan turnos disponibles para el Martes.")
    elif opcion_menu == "2":
        while True:
            dia_cancelar = input("¿que dia quiere cancelar? (lunes: 1  martes: 2): ") 
            if dia_cancelar == "1" or dia_cancelar == "2":
                break
            print("Error: Ingrese 1 o 2.")
        while True:
            paciente_canc = input("Nombre del paciente a cancelar: ")
            if paciente_canc == "" or not paciente_canc.isalpha():
                print("Error: Ingrese un nombre válido (solo letras).")
            else:
                break

        encontrado = False
        if dia_cancelar == "1":
            if paciente_canc == lunes1:
                lunes1 = ""
                encontrado = True
            elif paciente_canc == lunes2:
                lunes2 = ""
                encontrado = True
            elif paciente_canc == lunes3:
                lunes3 = ""
                encontrado = True
            elif paciente_canc == lunes4:
                lunes4 = ""
                encontrado = True
        elif dia_cancelar == "2":
            if paciente_canc == martes1:
                martes1 = ""
                encontrado = True
            elif paciente_canc == martes2:
                martes2 = ""
                encontrado = True
            elif paciente_canc == martes3:
                martes3 = ""
                encontrado = True
        if encontrado:
            print(f"El turno de {paciente_canc} ha sido cancelado con éxito.")
        else:
            print(f"Error: No se encontró ningún turno para {paciente_canc} ese día.")
    elif opcion_menu == "3":
        while True:
            dia_ver = input("¿Qué agenda desea ver? (1=Lunes, 2=Martes): ")
            if dia_ver == "1" or dia_ver == "2":
                break
            print("Error: Ingrese 1 o 2.")
        
        if dia_ver == "1":
            print("\n--- AGENDA LUNES ---")
            if lunes1 == "": print("Turno 1: (libre)")
            else: print(f"Turno 1: {lunes1}")
            
            if lunes2 == "": print("Turno 2: (libre)")
            else: print(f"Turno 2: {lunes2}")
            
            if lunes3 == "": print("Turno 3: (libre)")
            else: print(f"Turno 3: {lunes3}")
            
            if lunes4 == "": print("Turno 4: (libre)")
            else: print(f"Turno 4: {lunes4}")
        else:
            print("\n--- AGENDA MARTES ---")
            if martes1 == "": print("Turno 1: (libre)")
            else: print(f"Turno 1: {martes1}")
            
            if martes2 == "": print("Turno 2: (libre)")
            else: print(f"Turno 2: {martes2}")
            
            if martes3 == "": print("Turno 3: (libre)")
            else: print(f"Turno 3: {martes3}")
    elif opcion_menu == "4":
        occ_lunes = 0
        if lunes1 != "": occ_lunes += 1
        if lunes2 != "": occ_lunes += 1
        if lunes3 != "": occ_lunes += 1
        if lunes4 != "": occ_lunes += 1
        lib_lunes = 4 - occ_lunes
        
        occ_martes = 0
        if martes1 != "": occ_martes += 1
        if martes2 != "": occ_martes += 1
        if martes3 != "": occ_martes += 1
        lib_martes = 3 - occ_martes
        
        print("\n--- RESUMEN GENERAL ---")
        print(f"Lunes: {occ_lunes} ocupados y {lib_lunes} disponibles.")
        print(f"Martes: {occ_martes} ocupados y {lib_martes} disponibles.")
        
        if occ_lunes > occ_martes:
            print("Día con más turnos ocupados: Lunes")
        elif occ_martes > occ_lunes:
            print("Día con más turnos ocupados: Martes")
        else:
            print("Ambos días tienen la misma cantidad de turnos ocupados.")

    elif opcion_menu == "5":
        print(f"Cerrando sistema de turnos. ¡Hasta pronto {operador}!")

    else:
        print("Error: Opción fuera de rango (1-5).")
            
