# Ejercicio 2 — “Acceso al Campus y Menú Seguro”
# colocamos variables que nos indican en la tarea, estas son fijas
usuario_sistema = "alumno"
clave_sistema = "python123"
intentos= 1 
acceso_concedido = False
while intentos <= 3:# un bucle con condicion mientras esta sea verdadera permanece
    print(f"\n ---intentos {intentos}/3--- ")
    usuario = input("ingrese su usuario: ")
    clave = input("ingrese su clave: ")
    if usuario == usuario_sistema and clave == clave_sistema: 
        print("acceso concedido")
        acceso_concedido = True
        break
    else:
        print("error, credenciales invalidas")
        intentos += 1
if not acceso_concedido:
    print("cuenta bloqueada")
else:
    print("bienvenido al campus ")
opcion = ""
while opcion != "4": # entramos a las opciones y validamos cada opcion
    print("\n 1) estado   2) cambiar clave   3) mensaje   4) salir")
    opcion = input("escoja una opcion: ")
    if not opcion.isdigit():
        print("error, solo numeros ")
    elif int(opcion) < 1 or int(opcion) > 4:
        print("error, fuera de rango")
    else:
        if opcion == "1":
            print("estado: inscripto")
        elif opcion == "2":
            nueva_clave = input("ingrese la nueva clave (minimo 6 caracteres): ")
            if len(nueva_clave) < 6 :
                print("error, minimo 6 caracteres") 
            else:
                confirmacion = input("confirme la nueva clave: ")
                if nueva_clave == confirmacion:
                    clave_sistema = nueva_clave
                    print("clave cambiada con exito")
                else:
                    print("error, las claves no coinciden")
        elif opcion == "3":
            print("lo peor es momentaneo, el exito es eterno")
        elif opcion == "4": # opcion final 
            print("cerrando sesion... ")      