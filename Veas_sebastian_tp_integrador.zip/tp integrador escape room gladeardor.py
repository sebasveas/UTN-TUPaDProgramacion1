#Ejercicio 5 — “Escape Room:"La Arena del Gladiador"
# configuramos el personaje y validamos
while True:
    nombre = input("Nombre del Gladiador: ")
    if nombre != "" and nombre.isalpha():
        break
    print("Error: Solo se permiten letras.")

# inicio de las estadisticas
vida_gladiador = 100        
vida_enemigo = 100          
pociones = 3                
ataque_pesado_base = 15     
dano_enemigo = 12           
juego_activo = True         # boolean

print("\n=== INICIO DEL COMBATE ===")

# ciclo del combate
while vida_gladiador > 0 and vida_enemigo > 0:
    print(f"\n{nombre} (HP: {vida_gladiador}) vs Enemigo (HP: {vida_enemigo}) | Pociones: {pociones}")
    print("Elige acción:")
    print("1. Ataque Pesado")
    print("2. Ráfaga Veloz")
    print("3. Curar")

    # Validación del Menú
    while True:
        opcion = input("Opción: ")
        if opcion.isdigit():
            if opcion == "1" or opcion == "2" or opcion == "3":
                break
        print("Error: Ingrese un número válido (1, 2 o 3).")

    # turno del jugador
    if opcion == "1":
        # Acción A: Ataque Pesado
        dano_final = float(ataque_pesado_base)
        if vida_enemigo < 20:
            dano_final = ataque_pesado_base * 1.5  # Golpe Crítico (float)
            print("¡GOLPE CRÍTICO!")
        
        vida_enemigo -= dano_final
        print(f"¡Atacaste al enemigo por {dano_final} puntos de daño!")

    elif opcion == "2":
        # Acción B: Ráfaga Veloz (Bucle for)
        print(">> ¡Inicias una ráfaga de golpes!")
        for i in range(3):
            vida_enemigo -= 5
            print("> Golpe conectado por 5 de daño")

    elif opcion == "3":
        # Acción C: Curar
        if pociones > 0:
            vida_gladiador += 30
            if vida_gladiador > 100:
                vida_gladiador = 100
            pociones -= 1
            print(f"¡Te has curado! Vida actual: {vida_gladiador}")
        else:
            print("¡No quedan pociones! Has perdido el turno buscando una.")

    # turno del enemigo
    # Solo ataca si no ha muerto tras el golpe del jugador
    if vida_enemigo > 0:
        vida_gladiador -= dano_enemigo
        print(f">> ¡El enemigo te atacó por {dano_enemigo} puntos de daño!")

# fin del juego
if vida_gladiador > 0:
    print(f"\n¡VICTORIA! {nombre} ha ganado la batalla.")
else:
    print("\nDERROTA. Has caído en combate.")