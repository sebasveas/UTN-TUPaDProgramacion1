#Ejercicio 4 — “Escape Room: La Bóveda”
# iniciamos colocando variables
energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ""

# Variables para el control 
forzar_seguidos = 0  # Para anti-spam 

# validamos nombre del agente
while True:
    nombre_agente = input("Ingrese el nombre del agente (solo letras): ")
    if nombre_agente != "" and nombre_agente.isalpha():
        break
    print("Error: El nombre solo debe contener letras y no estar vacío.")

print(f"\n--- MISION: LA BÓVEDA ---")
print(f"Agente {nombre_agente}, debes abrir 3 cerraduras.")

# primer ciclo del juego
# El juego sigue mientras energía > 0, tiempo > 0, cerraduras < 3 y no haya bloqueo
while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3:
    
    # bloqueo por alarma 
    if alarma == True and tiempo <= 3:
        break #la derrota por bloqueo

    # Mostrar estado actual
    print(f"\nESTADO: Energía: {energia} | Tiempo: {tiempo} | Cerraduras: {cerraduras_abiertas}/3")
    print(f"Alarma: {'ACTIVA' if alarma else 'Apagada'} | Código: {codigo_parcial}")
    
    print("\nMENÚ DE ACCIONES:")
    print("1. Forzar cerradura (costo: -20 energía, -2 tiempo)")
    print("2. Hackear panel (costo: -10 energía, -3 tiempo)")
    print("3. Descansar (+15 energía, -1 tiempo)")
    
    # Validación de la opción 1
    while True:
        opcion = input("Elija una acción: ")
        if opcion.isdigit():
            if "1" <= opcion <= "3":
                break
        print("Error: Ingrese un número válido (1, 2 o 3).")

    # proceso de opciones
    
    if opcion == "1":
        energia -= 20
        tiempo -= 2
        forzar_seguidos += 1
        
        # Regla Anti-Spam
        if forzar_seguidos >= 3:
            print("¡LA CERRADURA SE TRABÓ! Se activó la alarma.")
            alarma = True
            # No abre cerradura por ser la 3ra vez seguida
        else:
            # riesgo
            if energia < 40:
                print("RIESGO DE ALARMA ALTO.")
                while True:
                    num = input("Elija un número de seguridad (1-3): ")
                    if num.isdigit() and "1" <= num <= "3":
                        break
                    print("Error: Ingrese 1, 2 o 3.")
                
                if num == "3":
                    alarma = True
                    print("¡FALLASTE! Alarma activada.")
            
            # Abrir cerradura si no hay alarma 
            if not alarma:
                cerraduras_abiertas += 1
                print("¡Cerradura abierta con éxito!")

    elif opcion == "2":
        # Hackear panel 
        forzar_seguidos = 0 # Corta la racha de forzar
        energia -= 10
        tiempo -= 3
        
        print("Hackeando panel...")
        for i in range(1, 5): # Bucle de 4 pasos
            codigo_parcial += "A"
            print(f"Progreso: {i*25}% - Código: {codigo_parcial}")
        
        if len(codigo_parcial) >= 8 and cerraduras_abiertas < 3:
            cerraduras_abiertas += 1
            print("¡El código completo abrió una cerradura!")

    elif opcion == "3":
        # Descansar 
        forzar_seguidos = 0 # Corta la racha de forzar
        tiempo -= 1
        
        ganancia = 15
        if alarma:
            ganancia -= 10 
            print("El descanso es difícil con la alarma sonando...")
        
        energia += ganancia
        if energia > 100:
            energia = 100
        print(f"Has descansado. Energía actual: {energia}")

# condiciones del final 
if cerraduras_abiertas == 3:
    print(f"\n¡VICTORIA! El Agente {nombre_agente} ha abierto la bóveda.")
elif energia <= 0 or tiempo <= 0:
    print(f"\nDERROTA. Te has quedado sin {'energía' if energia <= 0 else 'tiempo'}.")
elif alarma == True and tiempo <= 3:
    print("\nDERROTA. El sistema se bloqueó por la alarma. ¡Misión fallida!")